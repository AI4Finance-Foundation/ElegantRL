from AgentRun import run__demo

run__demo()