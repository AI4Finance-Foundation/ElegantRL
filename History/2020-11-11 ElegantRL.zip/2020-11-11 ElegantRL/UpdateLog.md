# UpdateLog of ElegantRL

#### ElegantRL 2019.??.?? (Yonder YonV)
I should spend time organising my historical update log.
Wait for adding...



#### ElegantRL 2020.08.08 (NewYork Necip)
build this update log
change the Github repository name from 'DL_RL_Zoo' into 'ElegantRL'.
It is still a beta version.
ElegantRL 2020.08.12 (NewYork Necip), where (NewYork Necip) is a codename for version ElegantRL 2020.08.12.
It is similar to Ubuntu 18.04 (Bionic Beaver)
Maybe the code name is (Casual ChuMeng), which is the next formal version.

#### ElegantRL 2020.08.12 (NewYork Necip)
Plan:
Check Dueling DQN
Add the training stop signal: reach the target reward, reach the total step.
Check InterISAC




####  ElegantRL 2020.??.?? (Casual ChuMeng)
ElegantRL 2020.08 (NewYork Necip), where Necip is a codename for version ElegantRL 2020.08
It is similar to Ubuntu 18.04 (Bionic Beaver)
Maybe the next codename is (Casual ChuMeng), which is a formal version with multi-agent RL.
The multi-agent RL task of rllib is so complex, and I need long time to reconstruct. 
