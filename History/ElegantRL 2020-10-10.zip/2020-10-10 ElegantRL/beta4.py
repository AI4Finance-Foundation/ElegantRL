import matplotlib.pyplot as plt
import numpy as np

cwd = ['/home/yonv/code/ElegantRL',
       '/home/yonv/code/ElegantRL_cwd/2020-10-05'][1]

name = ['AgentInterSAC/BipedalWalker-v3_7',
        ][0]

path = f'{cwd}/{name}/record_evaluate.npy'

ary = np.load(path)
print('ary.shape ==', ary.shape)

xs = ary[:, 0]
ys = ary[:, 1]
plt.plot(xs, ys)
plt.show()
