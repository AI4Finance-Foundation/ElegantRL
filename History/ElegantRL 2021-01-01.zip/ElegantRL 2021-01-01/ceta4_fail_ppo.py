from AgentRun import *


def run__kuka():
    # env = FinanceMultiStockEnv()  # 2020-12-24
    import gym  # gym of OpenAI is not necessary for ElegantRL (even RL)
    gym.logger.set_level(40)  # Block warning: 'WARN: Box bound precision lowered by casting to float32'
    import pybullet_envs  # for python-bullet-gym
    dir(pybullet_envs)
    env = decorate_env(env=gym.make('KukaBulletEnv-v0'), if_print=True) # PPO fail

    from AgentZoo import AgentPPO

    args = Arguments(rl_agent=AgentPPO, env=env)
    # args.gpu_id = 0
    args.eval_times1 = 2 ** 5
    args.eval_times2 = 2 ** 7
    args.rollout_workers_num = 4
    args.if_break_early = False

    args.reward_scale = 2 ** 0  # (0) 1.1 ~ 15 (19)
    args.break_step = int(5e6 * 4)  # 5e6 (15e6) UsedTime: 4,000s (12,000s)
    args.net_dim = 2 ** 7
    args.max_step = 2 ** 10
    args.max_memo = 2 ** 12  # 11
    args.batch_size = 2 ** 9  # 10
    args.repeat_times = 2 ** 4
    args.init_for_training()
    train_agent_mp(args)  # train_agent(args)
    exit()


if __name__ == '__main__':
    run__fin_rl()
